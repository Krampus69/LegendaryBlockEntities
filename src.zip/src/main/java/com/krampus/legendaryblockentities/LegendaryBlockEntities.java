package com.krampus.legendaryblockentities;

import com.mojang.logging.LogUtils;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.fml.loading.FMLEnvironment;
import org.slf4j.Logger;

/**
 * Legendary Block Entities — Forge 1.20.1 port of Enhanced Block Entities by FoundationGames.
 * <p>
 * Original mod: <a href="https://github.com/FoundationGames/EnhancedBlockEntities">EnhancedBlockEntities</a>
 * <br>Licensed under LGPL-3.0.
 * <p>
 * This is a client-only mod — it does not register anything on the dedicated server.
 */
@Mod(LegendaryBlockEntities.MOD_ID)
public final class LegendaryBlockEntities {
    public static final String MOD_ID = "legendaryblockentities";
    public static final String NAMESPACE = "lbe";
    public static final Logger LOG = LogUtils.getLogger();

    public LegendaryBlockEntities() {
        // Forge's mod constructor runs on both physical client and dedicated server.
        // Block entity rendering is meaningless server-side, so we early-out there.
        if (FMLEnvironment.dist != Dist.CLIENT) {
            LOG.debug("LegendaryBlockEntities is client-only; skipping registration on dedicated server.");
            return;
        }

        final IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        modBus.addListener(this::onClientSetup);

        LOG.info("Legendary Block Entities initialized (scaffolding only — no features active yet).");
    }

    private void onClientSetup(final FMLClientSetupEvent event) {
        // Logic will be wired in here in later slices:
        //   - register dynamic baked models via ModelEvent
        //   - register the runtime resource pack via AddPackFindersEvent (separate listener)
        //   - load config and call the per-block-entity setup methods
        LOG.info("Legendary Block Entities client setup complete (placeholder).");
    }
}
