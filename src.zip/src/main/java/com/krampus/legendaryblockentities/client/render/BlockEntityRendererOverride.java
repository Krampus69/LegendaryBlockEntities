package com.krampus.legendaryblockentities.client.render;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.world.level.block.entity.BlockEntity;

/**
 * Custom per-frame renderer for a block entity, used when the baked model alone
 * isn't enough (e.g. an animating chest lid). Called from
 * BlockEntityRenderDispatcherMixin in place of the vanilla BER.
 */
public abstract class BlockEntityRendererOverride {

    public static final BlockEntityRendererOverride NO_OP = new BlockEntityRendererOverride() {
        @Override
        public void render(BlockEntityRenderer<BlockEntity> renderer, BlockEntity blockEntity,
                           float partialTick, PoseStack poseStack, MultiBufferSource buffer,
                           int packedLight, int packedOverlay) {
            // intentionally blank
        }
    };

    public abstract void render(BlockEntityRenderer<BlockEntity> renderer,
                                BlockEntity blockEntity,
                                float partialTick,
                                PoseStack poseStack,
                                MultiBufferSource buffer,
                                int packedLight,
                                int packedOverlay);

    /** Called after a resource reload, in case the override caches BakedModel references. */
    public void onModelsReload() {}
}