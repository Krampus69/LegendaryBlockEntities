package com.krampus.legendaryblockentities.client.model;

import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.GsonHelper;
import net.minecraftforge.client.model.geometry.IGeometryLoader;

/**
 * Reads JSON model files of the form:
 * <pre>
 * {
 *   "loader": "legendaryblockentities:dynamic",
 *   "full":  "minecraft:block/chest_normal_center_full",
 *   "trunk": "minecraft:block/chest_normal_center_trunk"
 * }
 * </pre>
 */
public class DynamicGeometryLoader implements IGeometryLoader<DynamicGeometry> {
    @Override
    public DynamicGeometry read(JsonObject jsonObject, JsonDeserializationContext context) throws JsonParseException {
        ResourceLocation fullModel = new ResourceLocation(GsonHelper.getAsString(jsonObject, "full"));
        ResourceLocation trunkModel = new ResourceLocation(GsonHelper.getAsString(jsonObject, "trunk"));
        return new DynamicGeometry(fullModel, trunkModel);
    }
}
